<?php
 $a = 2;
 $b = 3;

 function bagi ($a, $b){
     $a=n  
 }