<!DOCTYPE html>
<html>
<body>
<?php
for ($i=1; $i<=50; $i++){
if($i%3==0){
    echo "Foo </br>";
}
elseif($i%5==0){
echo "Bar</br> ";
}
elseif($i%3==0 && $i%5==0 ){
    echo "FooBar</br>";
}else{
    echo +$i ;
}
}
?>
</html>
</body>
